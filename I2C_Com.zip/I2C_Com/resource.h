//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by I2C_Com.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_I2C_COM_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDB_Chip                        132
#define IDC_MensajeOut                  1000
#define IDC_Send                        1001
#define IDC_Receive                     1002
#define IDC_MensajeIn                   1003
#define IDC_Address                     1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
